WGANgp_main.py --- pretrained WGAN

my_function3.py --- end-to-end network generation to generate synthetic sequences

structure_compare_esm2.py --- Calculate feature distance

checkpoint/**.pth --- Model parameters for pre-trained models